#ifndef CAR_H
#define CAR_H

#include <stdbool.h>

typedef struct Car {
    int destination;
    int id;
    bool reachedDestination;
} Car;

Car* createCar(int destination);
void freeCar(Car* pCar);

#endif