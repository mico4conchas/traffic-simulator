// main.c
#include "trafficSimulator.h"
#include <stdio.h>

int main(int argc, char* argv[]) {
    if(argc != 2) {
        printf("Usage: %s <inputFile>\n", argv[0]);
        return 1;
    }

    printNames();
    
    TrafficData* trafficData = createTrafficData(argv[1]);
    if(trafficData == NULL) {
        printf("Failed to create traffic data\n");
        return 1;
    }

    trafficSimulator(trafficData);
    freeTrafficData(trafficData);

    return 0;
}