#include "graph.h"
#include <stdlib.h>
#include <limits.h>
#include "priorityQueue.h"
#include "road.h"
#include <stdbool.h>  // Add this if missing

Graph* createGraph(int numVertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->numVertices = numVertices;
    graph->edges = (Edge**)calloc(numVertices, sizeof(Edge*));
    return graph;
}

void freeGraph(Graph* graph) {
    if(graph == NULL) return;
    
    for(int i = 0; i < graph->numVertices; i++) {
        Edge* edge = graph->edges[i];
        while(edge != NULL) {
            Edge* temp = edge;
            edge = edge->next;
            free(temp);
        }
    }
    free(graph->edges);
    free(graph);
}

void addEdge(Graph* graph, int from, int to, int weight) {
    Edge* edge = (Edge*)malloc(sizeof(Edge));
    edge->to = to;
    edge->weight = weight;
    edge->data = NULL;
    edge->next = graph->edges[from];
    graph->edges[from] = edge;
}

void setEdgeData(Graph* graph, int from, int to, void* data) {
    Edge* edge = graph->edges[from];
    while(edge != NULL) {
        if(edge->to == to) {
            edge->data = data;
            return;
        }
        edge = edge->next;
    }
}

void* getEdgeData(Graph* graph, int from, int to) {
    Edge* edge = graph->edges[from];
    while(edge != NULL) {
        if(edge->to == to) {
            return edge->data;
        }
        edge = edge->next;
    }
    return NULL;
}

// Dijkstra's algorithm to find shortest path
int getNextOnShortestPath(Graph* graph, int start, int end) {
    if(start == end) return -1;
    
    int* dist = (int*)malloc(graph->numVertices * sizeof(int));
    int* prev = (int*)malloc(graph->numVertices * sizeof(int));
    bool* visited = (bool*)calloc(graph->numVertices, sizeof(bool));
    
    for(int i = 0; i < graph->numVertices; i++) {
        dist[i] = INT_MAX;
        prev[i] = -1;
    }
    dist[start] = 0;
    
    PriorityQueue* pq = createPQ();
    enqueueByPriority(pq, (void*)(long)start, 0);
    
    while(!isEmptyPQ(pq)) {
        int u = (int)(long)dequeuePQ(pq);
        if(u == end) break;
        if(visited[u]) continue;
        visited[u] = true;
        
        Edge* edge = graph->edges[u];
        while(edge != NULL) {
            int v = edge->to;
            int alt = dist[u] + edge->weight;
            if(alt < dist[v]) {
                dist[v] = alt;
                prev[v] = u;
                enqueueByPriority(pq, (void*)(long)v, alt);
            }
            edge = edge->next;
        }
    }
    
    freePQ(pq);
    free(visited);
    
    // Trace back path
    if(prev[end] == -1) {
        free(dist);
        free(prev);
        return -1; // No path exists
    }
    
    int next = end;
    while(prev[next] != start) {
        next = prev[next];
    }
    
    free(dist);
    free(prev);
    return next;
}

bool hasEdge(Graph* graph, int from, int to) {
    Edge* edge = graph->edges[from];
    while(edge != NULL) {
        if(edge->to == to) {
            return true;
        }
        edge = edge->next;
    }
    return false;
}