#ifndef ROAD_H
#define ROAD_H

#include "car.h"
#include "queue.h"

typedef enum {RED, GREEN} LightColor;

typedef struct RoadData {
    // Road properties
    int length;               // Length of the road in segments
    int startIntersect;       // Starting intersection ID
    int endIntersect;         // Ending intersection ID
    
    // Traffic light properties
    LightColor lightColor;    // Current light color
    int greenStartTime;       // Time when light turns green in cycle
    int greenEndTime;         // Time when light turns red in cycle
    int lightCycleLength;     // Total duration of light cycle
    
    // Car management
    Car** carsOnRoad;         // Array of cars currently on the road
    Queue* waitingCars;       // Queue of cars waiting to enter the road
    int carCount;             // Number of cars currently on the road
    
    // Linked list pointer
    struct RoadData* next;    // Pointer to next road in linked list
    
    // Statistics (optional)
    int totalCarsPassed;      // Total cars that have traversed this road
    int maxWaitTime;          // Maximum time cars waited at this road
} RoadData;

/* Creates a new road with given parameters
 * Parameters:
 *   length - number of segments in the road
 *   from - starting intersection ID
 *   to - ending intersection ID
 *   greenStart - start time of green light in cycle
 *   greenEnd - end time of green light in cycle
 *   cycle - total duration of traffic light cycle
 * Returns pointer to newly created road or NULL on failure
 */
RoadData* createRoad(int length, int from, int to, int greenStart, int greenEnd, int cycle);

/* Frees all memory associated with a road
 * Parameters:
 *   road - pointer to road to be freed
 */
void freeRoad(RoadData* road);

/* Updates the traffic light state based on current time
 * Parameters:
 *   road - road whose light should be updated
 *   timeStep - current simulation time step
 */
void updateTrafficLight(RoadData* road, int timeStep);

/* Prints the current status of the road
 * Parameters:
 *   road - road to print status for
 *   timeStep - current simulation time step
 */
void printRoadStatus(RoadData* road, int timeStep);

#endif