#ifndef EVENT_H
#define EVENT_H

#include "car.h"

typedef enum {ADD_CAR_EVENT, PRINT_ROADS_EVENT} EventType;

typedef struct Event {
    EventType eventType;
    int timeStep;
    Car* pCar;
    int roadFrom;
} Event;

Event* createEvent(EventType type, int timeStep, Car* pCar, int roadFrom);
void freeEvent(Event* pEvent);

#endif