#include "car.h"
#include <stdlib.h>

Car* createCar(int destination) {
    Car* car = (Car*)malloc(sizeof(Car));
    if(car != NULL) {
        car->destination = destination;
        car->id = -1; // To be set later
        car->reachedDestination = false;
    }
    return car;
}

void freeCar(Car* pCar) {
    if(pCar != NULL) {
        free(pCar);
    }
}