#ifndef TRAFFIC_SIMULATOR_H
#define TRAFFIC_SIMULATOR_H

#include "graph.h"
#include "priorityQueue.h"
#include "road.h"
#include "car.h"
#include "event.h"

typedef struct TrafficData {
    Graph* roadNetwork;
    struct RoadData* roadsList;  // Changed to struct RoadData*
    PriorityQueue* eventsQueue;
    int numCars;
    int carsInTransit;
    int longestLightCycle;
} TrafficData;

void printNames();
TrafficData* createTrafficData(char* filename);
void trafficSimulator(TrafficData* pTrafficData);
void freeTrafficData(TrafficData* pTrafficData);
void printAllRoadsStatus(TrafficData* pTrafficData, int timeStep);
int max(int a, int b);

#endif