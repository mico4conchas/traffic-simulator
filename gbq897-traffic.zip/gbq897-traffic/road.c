#include "road.h"
#include <stdlib.h>
#include <stdio.h>

RoadData* createRoad(int length, int from, int to, int greenStart, int greenEnd, int cycle) {
    RoadData* road = (RoadData*)malloc(sizeof(RoadData));
    if (road == NULL) return NULL;

    // Initialize all fields
    road->length = length;
    road->startIntersect = from;
    road->endIntersect = to;
    road->greenStartTime = greenStart;
    road->greenEndTime = greenEnd;
    road->lightCycleLength = cycle;
    road->lightColor = RED;
    road->carCount = 0;
    road->next = NULL;
    road->totalCarsPassed = 0;
    road->maxWaitTime = 0;
    
    // Initialize cars array
    road->carsOnRoad = (Car**)calloc(length, sizeof(Car*));
    if (road->carsOnRoad == NULL) {
        free(road);
        return NULL;
    }
    
    road->waitingCars = createQueue();
    return road;
}

void freeRoad(RoadData* road) {
    if (road == NULL) return;
    
    // Free individual cars (if needed)
    // Note: Cars are typically freed by the simulator
    free(road->carsOnRoad);
    freeQueue(road->waitingCars);  // Doesn't free cars, just the queue
    free(road);
}

void updateTrafficLight(RoadData* road, int timeStep) {
    if (road == NULL) return;
    
    int cycleTime = timeStep % road->lightCycleLength;
    road->lightColor = (cycleTime >= road->greenStartTime && 
                       cycleTime < road->greenEndTime) ? GREEN : RED;
}

void printRoadStatus(RoadData* road, int timeStep) {
    if (road == NULL) return;
    
    printf("Road %d->%d (%s): ", road->startIntersect, road->endIntersect,
          road->lightColor == GREEN ? "GREEN" : "RED");
    
    // Print cars on road
    int carsPrinted = 0;
    for (int i = 0; i < road->length; i++) {
        if (road->carsOnRoad[i] != NULL) {
            printf("[%d]", road->carsOnRoad[i]->id);
            carsPrinted++;
        }
    }
    
    // Print waiting cars if any
    if (!isEmpty(road->waitingCars)) {
        printf(" Waiting:");
        Queue* temp = createQueue();
        while (!isEmpty(road->waitingCars)) {
            Car* car = (Car*)dequeue(road->waitingCars);
            printf(" %d", car->id);
            enqueue(temp, car);
        }
        // Restore the queue
        while (!isEmpty(temp)) {
            enqueue(road->waitingCars, dequeue(temp));
        }
        freeQueue(temp);
    }
    
    if (carsPrinted == 0 && isEmpty(road->waitingCars)) {
        printf("Empty");
    }
    printf("\n");
}