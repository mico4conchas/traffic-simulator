#include "trafficSimulator.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <ctype.h>

/* Helper function to find maximum of two numbers */
int max(int a, int b) {
    return (a > b) ? a : b;
}

/* Helper function to skip comments and whitespace */
static void skipCommentsAndWhitespace(FILE* file) {
    int c;
    while ((c = fgetc(file)) != EOF) {
        if (c == '#') {
            while ((c = fgetc(file)) != '\n' && c != EOF);
        } 
        else if (!isspace(c)) {
            ungetc(c, file);
            break;
        }
    }
}

void printNames() {
    printf("\nThis solution was completed by:\n");
    printf("Nadia Jones\n");
    printf("Miguel Corona\n\n");
}

/* Creates and initializes TrafficData structure */
TrafficData* createTrafficData(char* filename) {
    FILE *pFile = fopen(filename, "r");
    if(pFile == NULL) {
        printf("ERROR: Could not open file %s\n", filename);
        return NULL;
    }

    // Read size and edges
    skipCommentsAndWhitespace(pFile);
    int size, edges;
    if(fscanf(pFile, "%d %d", &size, &edges) != 2) {
        printf("ERROR: First line must contain two integers (size edges)\n");
        fclose(pFile);
        return NULL;
    }

    TrafficData* tData = (TrafficData*)malloc(sizeof(TrafficData));
    if(tData == NULL) {
        fclose(pFile);
        return NULL;
    }

    tData->roadNetwork = createGraph(size);
    tData->roadsList = NULL;
    tData->eventsQueue = createPQ();
    tData->numCars = 0;
    tData->carsInTransit = 0;
    tData->longestLightCycle = 0;

    // Read road data
    for(int i = 0; i < size; i++) {
        skipCommentsAndWhitespace(pFile);
        int incomingRoads;
        if(fscanf(pFile, "%d", &incomingRoads) != 1) {
            printf("ERROR: Expected incoming road count for intersection %d\n", i);
            freeTrafficData(tData);
            fclose(pFile);
            return NULL;
        }

        for(int j = 0; j < incomingRoads; j++) {
            skipCommentsAndWhitespace(pFile);
            int from, length, greenStart, greenEnd, cycle;
            if(fscanf(pFile, "%d %d %d %d %d", &from, &length, &greenStart, &greenEnd, &cycle) != 5) {
                printf("ERROR: Invalid road parameters for intersection %d, road %d\n", i, j);
                freeTrafficData(tData);
                fclose(pFile);
                return NULL;
            }

            RoadData* road = createRoad(length, from, i, greenStart, greenEnd, cycle);
            if(road == NULL) {
                printf("ERROR: Failed to create road\n");
                freeTrafficData(tData);
                fclose(pFile);
                return NULL;
            }

            // Add to linked list and graph
            road->next = tData->roadsList;
            tData->roadsList = road;
            addEdge(tData->roadNetwork, from, i, length);
            setEdgeData(tData->roadNetwork, from, i, road);

            tData->longestLightCycle = max(tData->longestLightCycle, cycle);
        }
    }

    // Read car data
    skipCommentsAndWhitespace(pFile);
    int numCars;
    if(fscanf(pFile, "%d", &numCars) != 1) {
        printf("ERROR: Invalid car count\n");
        freeTrafficData(tData);
        fclose(pFile);
        return NULL;
    }

    tData->numCars = numCars;
    tData->carsInTransit = numCars;

    for(int i = 0; i < numCars; i++) {
        skipCommentsAndWhitespace(pFile);
        int from, dest, time;
        if(fscanf(pFile, "%d %d %d", &from, &dest, &time) != 3) {
            printf("ERROR: Invalid car data for car %d\n", i);
            freeTrafficData(tData);
            fclose(pFile);
            return NULL;
        }

        Car* car = createCar(dest);
        car->id = i;
        Event* event = createEvent(ADD_CAR_EVENT, time, car, from);
        enqueueByPriority(tData->eventsQueue, event, time);
    }

    fclose(pFile);
    return tData;
}

/* Moves cars through intersections with improved pathfinding */
void moveCarsThroughIntersection(TrafficData* pTrafficData, int intersection) {
    if(pTrafficData == NULL) return;
    
    RoadData* road = pTrafficData->roadsList;
    while(road != NULL) {
        if(road->endIntersect == intersection && road->lightColor == GREEN && !isEmpty(road->waitingCars)) {
            Car* car = (Car*)dequeue(road->waitingCars);
            
            // Check if already at destination
            if(intersection == car->destination) {
                printf("Car %d reached destination %d\n", car->id, car->destination);
                pTrafficData->carsInTransit--;
                freeCar(car);
                road = road->next;
                continue;
            }

            // Try shortest path first
            int next = getNextOnShortestPath(pTrafficData->roadNetwork, intersection, car->destination);
            RoadData* nextRoad = NULL;
            
            // If no path, find any available green light road
            if(next == -1) {
                RoadData* temp = pTrafficData->roadsList;
                while(temp != NULL) {
                    if(temp->startIntersect == intersection && temp != road && temp->lightColor == GREEN) {
                        next = temp->endIntersect;
                        nextRoad = temp;
                        break;
                    }
                    temp = temp->next;
                }
            } else {
                // Find the preferred road
                RoadData* temp = pTrafficData->roadsList;
                while(temp != NULL) {
                    if(temp->startIntersect == intersection && temp->endIntersect == next) {
                        nextRoad = temp;
                        break;
                    }
                    temp = temp->next;
                }
            }

            if(nextRoad != NULL && nextRoad->lightColor == GREEN) {
                enqueue(nextRoad->waitingCars, car);
                printf("Car %d moved from %d to %d (dest %d)\n", 
                      car->id, intersection, nextRoad->endIntersect, car->destination);
            } else {
                // Try any available road as last resort
                RoadData* altRoad = pTrafficData->roadsList;
                while(altRoad != NULL) {
                    if(altRoad->startIntersect == intersection && altRoad != road && altRoad->lightColor == GREEN) {
                        enqueue(altRoad->waitingCars, car);
                        printf("Car %d rerouted from %d to %d (dest %d)\n",
                              car->id, intersection, altRoad->endIntersect, car->destination);
                        break;
                    }
                    altRoad = altRoad->next;
                }
                
                if(altRoad == NULL) {
                    printf("Car %d stuck at intersection %d - no available routes\n", car->id, intersection);
                    freeCar(car);
                    pTrafficData->carsInTransit--;
                }
            }
        }
        road = road->next;
    }
}

/* Moves cars along roads with traffic light awareness */
void moveCarsOnRoad(RoadData* road, int timeStep) {
    if(road == NULL) return;

    bool moved = false;
    
    // Move car from end to intersection if light is green
    if(road->carsOnRoad[road->length-1] != NULL && road->lightColor == GREEN) {
        Car* car = road->carsOnRoad[road->length-1];
        enqueue(road->waitingCars, car);
        road->carsOnRoad[road->length-1] = NULL;
        road->carCount--;
        moved = true;
    }

    // Move cars forward
    for(int i = road->length-2; i >= 0; i--) {
        if(road->carsOnRoad[i] != NULL && road->carsOnRoad[i+1] == NULL) {
            road->carsOnRoad[i+1] = road->carsOnRoad[i];
            road->carsOnRoad[i] = NULL;
            moved = true;
        }
    }

    // Move car from queue to road start
    if(road->carsOnRoad[0] == NULL && !isEmpty(road->waitingCars)) {
        road->carsOnRoad[0] = (Car*)dequeue(road->waitingCars);
        road->carCount++;
        moved = true;
    }

    if(moved) {
        printf("Road %d->%d: cars moved at time %d\n", 
              road->startIntersect, road->endIntersect, timeStep);
    }
}

/* Improved gridlock detection */
bool isGridlocked(TrafficData* pTrafficData, int timeStep) {
    if(pTrafficData == NULL || pTrafficData->carsInTransit == 0) 
        return false;

    static int lastMovementTime = -1;
    static int lastCarCount = -1;  // Initialize to invalid value
    
    // First-time initialization
    if(lastCarCount == -1) {
        lastCarCount = pTrafficData->carsInTransit;
        return false;
    }
    
    // If cars have moved since last check
    if(pTrafficData->carsInTransit < lastCarCount) {
        lastMovementTime = timeStep;
        lastCarCount = pTrafficData->carsInTransit;
        return false;
    }
    
    // Check if stuck for more than 2 full light cycles
    if(lastMovementTime != -1 && (timeStep - lastMovementTime) > pTrafficData->longestLightCycle * 2) {
        return true;
    }

    // Check all roads for possible movement
    RoadData* road = pTrafficData->roadsList;
    while(road != NULL) {
        // Check if cars can move forward
        for(int i = 0; i < road->length-1; i++) {
            if(road->carsOnRoad[i] != NULL && road->carsOnRoad[i+1] == NULL) {
                return false;
            }
        }
        
        // Check if cars can exit road
        if(road->carsOnRoad[road->length-1] != NULL && road->lightColor == GREEN) {
            return false;
        }
        
        // Check if cars can enter road
        if(!isEmpty(road->waitingCars) && road->carsOnRoad[0] == NULL) {
            return false;
        }
        
        road = road->next;
    }
    
    return true;
}

bool allCarsAtDestination(TrafficData* pTrafficData) {
    return pTrafficData == NULL || pTrafficData->carsInTransit == 0;
}

void printAllRoadsStatus(TrafficData* pTrafficData, int timeStep) {
    if(pTrafficData == NULL) return;
    
    printf("\n=== ROAD STATUS AT TIME %d ===\n", timeStep);
    RoadData* road = pTrafficData->roadsList;
    while(road != NULL) {
        printRoadStatus(road, timeStep);
        road = road->next;
    }
}

/* Main simulation loop with improved termination conditions */
void trafficSimulator(TrafficData* pTrafficData) {
    if(pTrafficData == NULL) return;
    
    int timeStep = 0;
    bool done = false;
    const int MAX_STEPS = 1000;
    
    while(!done && timeStep < MAX_STEPS) {
        // Process events for current time
        while(!isEmptyPQ(pTrafficData->eventsQueue) && 
              getFrontPriority(pTrafficData->eventsQueue) == timeStep) {
            Event* event = dequeuePQ(pTrafficData->eventsQueue);
            
            if(event->eventType == ADD_CAR_EVENT) {
                RoadData* road = pTrafficData->roadsList;
                while(road != NULL) {
                    if(road->startIntersect == event->roadFrom) {
                        enqueue(road->waitingCars, event->pCar);
                        printf("Added car %d to road %d->%d (dest %d)\n", 
                              event->pCar->id, road->startIntersect, 
                              road->endIntersect, event->pCar->destination);
                        break;
                    }
                    road = road->next;
                }
            }
            freeEvent(event);
        }
        
        // Update all traffic lights
        RoadData* road = pTrafficData->roadsList;
        while(road != NULL) {
            updateTrafficLight(road, timeStep);
            road = road->next;
        }
        
        // Move cars through intersections
        for(int i = 0; i < pTrafficData->roadNetwork->numVertices; i++) {
            moveCarsThroughIntersection(pTrafficData, i);
        }
        
        // Move cars along roads
        road = pTrafficData->roadsList;
        while(road != NULL) {
            moveCarsOnRoad(road, timeStep);
            road = road->next;
        }
        
        // Check termination conditions
        if(allCarsAtDestination(pTrafficData)) {
            printf("\nALL CARS REACHED THEIR DESTINATIONS!\n");
            done = true;
        }
        else if(isGridlocked(pTrafficData, timeStep)) {
            printf("\nGRIDLOCK DETECTED AT TIME %d! SIMULATION STOPPED.\n", timeStep);
            printf("Cars remaining in transit: %d\n", pTrafficData->carsInTransit);
            
            // Print detailed stuck information
            road = pTrafficData->roadsList;
            while(road != NULL) {
                for(int i = 0; i < road->length; i++) {
                    if(road->carsOnRoad[i] != NULL) {
                        printf("Car %d stuck on road %d->%d at position %d\n",
                              road->carsOnRoad[i]->id, 
                              road->startIntersect,
                              road->endIntersect,
                              i);
                    }
                }
                if(!isEmpty(road->waitingCars)) {
                    printf("Cars waiting at road %d->%d\n",
                          road->startIntersect, road->endIntersect);
                }
                road = road->next;
            }
            done = true;
        }
        
        // Print status periodically
        if(timeStep % 5 == 0 || done) {
            printAllRoadsStatus(pTrafficData, timeStep);
        }
        
        timeStep++;
    }
    
    if(timeStep >= MAX_STEPS) {
        printf("\nMAXIMUM TIME STEPS REACHED! SIMULATION STOPPED.\n");
        printf("Cars remaining in transit: %d\n", pTrafficData->carsInTransit);
        
        // Print detailed stuck information
        RoadData* road = pTrafficData->roadsList;
        while(road != NULL) {
            for(int i = 0; i < road->length; i++) {
                if(road->carsOnRoad[i] != NULL) {
                    printf("Car %d stuck on road %d->%d at position %d\n",
                          road->carsOnRoad[i]->id, 
                          road->startIntersect,
                          road->endIntersect,
                          i);
                }
            }
            if(!isEmpty(road->waitingCars)) {
                printf("Cars waiting at road %d->%d\n",
                      road->startIntersect, road->endIntersect);
            }
            road = road->next;
        }
    }
}

/* Properly frees all allocated memory */
void freeTrafficData(TrafficData* pTrafficData) {
    if(pTrafficData == NULL) return;

    // Free all roads and their cars
    RoadData* road = pTrafficData->roadsList;
    while(road != NULL) {
        RoadData* nextRoad = road->next;
        
        // Free cars on road
        for(int i = 0; i < road->length; i++) {
            if(road->carsOnRoad[i] != NULL) {
                freeCar(road->carsOnRoad[i]);
            }
        }
        free(road->carsOnRoad);
        
        // Free waiting cars
        while(!isEmpty(road->waitingCars)) {
            Car* car = (Car*)dequeue(road->waitingCars);
            freeCar(car);
        }
        freeQueue(road->waitingCars);
        free(road);
        
        road = nextRoad;
    }

    // Free remaining events
    while(!isEmptyPQ(pTrafficData->eventsQueue)) {
        Event* event = dequeuePQ(pTrafficData->eventsQueue);
        if(event->pCar != NULL) {
            freeCar(event->pCar);
        }
        freeEvent(event);
    }
    freePQ(pTrafficData->eventsQueue);

    freeGraph(pTrafficData->roadNetwork);
    free(pTrafficData);
}