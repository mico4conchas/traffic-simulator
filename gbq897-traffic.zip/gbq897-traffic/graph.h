#ifndef GRAPH_H
#define GRAPH_H

#include <stdbool.h>

typedef struct Edge {
    int to;
    int weight;
    void* data;  // For storing RoadData
    struct Edge* next;
} Edge;

typedef struct Graph {
    int numVertices;
    Edge** edges;  // Adjacency list
} Graph;

// Graph operations
Graph* createGraph(int numVertices);
void freeGraph(Graph* graph);
void addEdge(Graph* graph, int from, int to, int weight);
void setEdgeData(Graph* graph, int from, int to, void* data);
void* getEdgeData(Graph* graph, int from, int to);
int getNextOnShortestPath(Graph* graph, int start, int end);
bool hasEdge(Graph* graph, int from, int to);

#endif