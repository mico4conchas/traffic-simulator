#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H

#include <stdbool.h>
typedef struct PriorityQueueNode {
    void* data;
    int priority;
    struct PriorityQueueNode* next;
} PriorityQueueNode;

typedef struct PriorityQueue {
    PriorityQueueNode* head;
    int size;
} PriorityQueue;

PriorityQueue* createPQ();
void freePQ(PriorityQueue* pq);
void enqueueByPriority(PriorityQueue* pq, void* data, int priority);
void* dequeuePQ(PriorityQueue* pq);
bool isEmptyPQ(PriorityQueue* pq);
int getFrontPriority(PriorityQueue* pq);

#endif