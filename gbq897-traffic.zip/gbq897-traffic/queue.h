#ifndef QUEUE_H
#define QUEUE_H

#include <stdbool.h>

typedef struct QueueNode {
    void* data;
    struct QueueNode* next;
} QueueNode;

typedef struct Queue {
    QueueNode* front;
    QueueNode* rear;
    int size;
} Queue;

Queue* createQueue();
void freeQueue(Queue* queue);
void enqueue(Queue* queue, void* data);
void* dequeue(Queue* queue);
bool isEmpty(Queue* queue);

#endif