#include "event.h"
#include <stdlib.h>

Event* createEvent(EventType type, int timeStep, Car* pCar, int roadFrom) {
    Event* event = (Event*)malloc(sizeof(Event));
    if(event != NULL) {
        event->eventType = type;
        event->timeStep = timeStep;
        event->pCar = pCar;
        event->roadFrom = roadFrom;
    }
    return event;
}

void freeEvent(Event* pEvent) {
    if(pEvent != NULL) {
        free(pEvent);
    }
}