#include "priorityQueue.h"
#include <stdlib.h>
#include <stdbool.h>

PriorityQueue* createPQ() {
    PriorityQueue* pq = (PriorityQueue*)malloc(sizeof(PriorityQueue));
    if (pq == NULL) return NULL;
    pq->head = NULL;
    pq->size = 0;
    return pq;
}

void freePQ(PriorityQueue* pq) {
    if (pq == NULL) return;
    PriorityQueueNode* current = pq->head;
    while (current != NULL) {
        PriorityQueueNode* temp = current;
        current = current->next;
        free(temp);
    }
    free(pq);
}

void enqueueByPriority(PriorityQueue* pq, void* data, int priority) {
    PriorityQueueNode* newNode = (PriorityQueueNode*)malloc(sizeof(PriorityQueueNode));
    newNode->data = data;
    newNode->priority = priority;
    newNode->next = NULL;

    if (pq->head == NULL || priority < pq->head->priority) {
        newNode->next = pq->head;
        pq->head = newNode;
    } else {
        PriorityQueueNode* current = pq->head;
        while (current->next != NULL && current->next->priority <= priority) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
    pq->size++;
}

void* dequeuePQ(PriorityQueue* pq) {
    if (isEmptyPQ(pq)) return NULL;
    PriorityQueueNode* temp = pq->head;
    void* data = temp->data;
    pq->head = pq->head->next;
    free(temp);
    pq->size--;
    return data;
}

bool isEmptyPQ(PriorityQueue* pq) {
    return pq->head == NULL;
}

int getFrontPriority(PriorityQueue* pq) {
    if (isEmptyPQ(pq)) return -1;
    return pq->head->priority;
}